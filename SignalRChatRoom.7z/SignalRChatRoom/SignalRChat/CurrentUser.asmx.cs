﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Xml;

namespace SignalRChat
{
    /// <summary>
    /// Summary description for CurrentUser
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class CurrentUser : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        public class Users
        {
            public string UserName { get; set; }
            public string IpAddress { get; set; }
            public string Countrycode { get; set; }
            public string Countryname { get; set; }
            public string City { get; set; }
            public string Time { get; set; }
        }
       
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetCurrentUser()
        {
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            //Users[] emps = new Users[10];
            XmlDocument xmlEmloyeeDoc = new XmlDocument();
            xmlEmloyeeDoc.Load(HttpContext.Current.Server.MapPath("~/UserRecord.xml"));
            List<Users> emps = new List<Users>(0);
            XmlNodeList Datas = xmlEmloyeeDoc.SelectNodes("Users");
            
            foreach (XmlNode Data in xmlEmloyeeDoc.SelectNodes("Users"))
            {

                for (int i = Data.ChildNodes.Count-1; i >= 0; i--)
                {
                    XmlNode Nnode = Data.ChildNodes.Item(i);

                    var s = new Users()
                      {
                          UserName = Nnode["Name"].InnerText,
                          IpAddress = Nnode["IP"].InnerText,
                          Countrycode = Nnode["country_code"].InnerText,
                          Countryname = Nnode["country_name"].InnerText,
                          City = Nnode["city"].InnerText,
                          Time = Nnode["Time"].InnerText,
                      };

                    emps.Add(s);
                }


            }
         

            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(serializer.Serialize(emps));


           
        }
    }
}
